#this file is generated from tqix setup.py
version = '3.0.2'
