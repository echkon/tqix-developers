# tqix
 >>> tqix: a Toolbox for Quantum in X:
 >>>    x: quantum measurement, quantum metrology, quantum tomography, and more.

# description
 >>> tqix is open-source software providing some convenient tools 
     for quantum measurement, quantum metrology, quantum tomography and more.

# license
 >>> copyright (c) 2019 and later\
 >>> authors: Le Bin Ho\
 >>> all rights reserved.

# note for installation:
 >>> download source code and run:
 >>> ```
 >>> $ pip3 install .
 >>> ```
 >>> install from pypi, run:
 >>> ```
 >>> $ pip3 install tqix
 >>> ```