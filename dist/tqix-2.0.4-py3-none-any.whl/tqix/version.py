#this file is generated from tqix setup.py
version = '2.0.4'
